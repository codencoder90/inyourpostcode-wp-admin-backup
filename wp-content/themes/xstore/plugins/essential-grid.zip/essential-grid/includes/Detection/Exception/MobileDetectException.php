<?php

namespace Esg\Detection\Exception;

class MobileDetectException extends \Exception
{
}
