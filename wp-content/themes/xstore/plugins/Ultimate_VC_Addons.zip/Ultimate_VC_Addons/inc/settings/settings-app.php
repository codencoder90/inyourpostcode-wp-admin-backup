<?php
/**
 * Single page settings page
 *
 * @package Ultimate VC Addons
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div id="uavc-settings-app" class="uavc-settings-app">

</div>
